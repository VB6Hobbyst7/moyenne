package nl.pdeg.moyenne;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class starter_subs_0 {


public static RemoteObject  _application_error(RemoteObject _error,RemoteObject _stacktrace) throws Exception{
try {
		Debug.PushSubsStack("Application_Error (starter) ","starter",1,starter.processBA,starter.mostCurrent,29);
if (RapidSub.canDelegate("application_error")) { return nl.pdeg.moyenne.starter.remoteMe.runUserSub(false, "starter","application_error", _error, _stacktrace);}
Debug.locals.put("Error", _error);
Debug.locals.put("StackTrace", _stacktrace);
 BA.debugLineNum = 29;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 30;BA.debugLine="Return True";
Debug.ShouldStop(536870912);
if (true) return starter.mostCurrent.__c.getField(true,"True");
 BA.debugLineNum = 31;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable(false);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Dim clsFunc As clsFunctions";
starter._clsfunc = RemoteObject.createNew ("nl.pdeg.moyenne.clsfunctions");
 //BA.debugLineNum = 8;BA.debugLine="Dim clsDbe As clsDb";
starter._clsdbe = RemoteObject.createNew ("nl.pdeg.moyenne.clsdb");
 //BA.debugLineNum = 9;BA.debugLine="Dim rp As RuntimePermissions";
starter._rp = RemoteObject.createNew ("anywheresoftware.b4a.objects.RuntimePermissions");
 //BA.debugLineNum = 10;BA.debugLine="Public share As String";
starter._share = RemoteObject.createImmutable("");
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _service_create() throws Exception{
try {
		Debug.PushSubsStack("Service_Create (starter) ","starter",1,starter.processBA,starter.mostCurrent,13);
if (RapidSub.canDelegate("service_create")) { return nl.pdeg.moyenne.starter.remoteMe.runUserSub(false, "starter","service_create");}
 BA.debugLineNum = 13;BA.debugLine="Sub Service_Create";
Debug.ShouldStop(4096);
 BA.debugLineNum = 14;BA.debugLine="share  = rp.GetSafeDirDefaultExternal(\"irp_files\"";
Debug.ShouldStop(8192);
starter._share = starter._rp.runMethod(true,"GetSafeDirDefaultExternal",(Object)(RemoteObject.createImmutable("irp_files")));
 BA.debugLineNum = 15;BA.debugLine="clsFunc.Initialize";
Debug.ShouldStop(16384);
starter._clsfunc.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_initialize" /*RemoteObject*/ ,starter.processBA);
 BA.debugLineNum = 16;BA.debugLine="clsDbe.Initialize";
Debug.ShouldStop(32768);
starter._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_initialize" /*RemoteObject*/ ,starter.processBA);
 BA.debugLineNum = 17;BA.debugLine="clsDbe.disciplineExists(\"\")";
Debug.ShouldStop(65536);
starter._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_disciplineexists" /*RemoteObject*/ ,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 18;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _service_destroy() throws Exception{
try {
		Debug.PushSubsStack("Service_Destroy (starter) ","starter",1,starter.processBA,starter.mostCurrent,33);
if (RapidSub.canDelegate("service_destroy")) { return nl.pdeg.moyenne.starter.remoteMe.runUserSub(false, "starter","service_destroy");}
 BA.debugLineNum = 33;BA.debugLine="Sub Service_Destroy";
Debug.ShouldStop(1);
 BA.debugLineNum = 35;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _service_start(RemoteObject _startingintent) throws Exception{
try {
		Debug.PushSubsStack("Service_Start (starter) ","starter",1,starter.processBA,starter.mostCurrent,20);
if (RapidSub.canDelegate("service_start")) { return nl.pdeg.moyenne.starter.remoteMe.runUserSub(false, "starter","service_start", _startingintent);}
Debug.locals.put("StartingIntent", _startingintent);
 BA.debugLineNum = 20;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
Debug.ShouldStop(524288);
 BA.debugLineNum = 21;BA.debugLine="Service.StopAutomaticForeground 'Starter service";
Debug.ShouldStop(1048576);
starter.mostCurrent._service.runVoidMethod ("StopAutomaticForeground");
 BA.debugLineNum = 22;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _service_taskremoved() throws Exception{
try {
		Debug.PushSubsStack("Service_TaskRemoved (starter) ","starter",1,starter.processBA,starter.mostCurrent,24);
if (RapidSub.canDelegate("service_taskremoved")) { return nl.pdeg.moyenne.starter.remoteMe.runUserSub(false, "starter","service_taskremoved");}
 BA.debugLineNum = 24;BA.debugLine="Sub Service_TaskRemoved";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 26;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}