package nl.pdeg.moyenne;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class clsdb_subs_0 {


public static RemoteObject  _adddiscipline(RemoteObject __ref,RemoteObject _disc,RemoteObject _disciid) throws Exception{
try {
		Debug.PushSubsStack("addDiscipline (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,23);
if (RapidSub.canDelegate("adddiscipline")) { return __ref.runUserSub(false, "clsdb","adddiscipline", __ref, _disc, _disciid);}
Debug.locals.put("disc", _disc);
Debug.locals.put("disciId", _disciid);
 BA.debugLineNum = 23;BA.debugLine="Sub addDiscipline(disc As String, disciId As Strin";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 24;BA.debugLine="initDb";
Debug.ShouldStop(8388608);
__ref.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_initdb" /*RemoteObject*/ );
 BA.debugLineNum = 25;BA.debugLine="If disciplineExists(disc) = True Then";
Debug.ShouldStop(16777216);
if (RemoteObject.solveBoolean("=",__ref.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_disciplineexists" /*RemoteObject*/ ,(Object)(_disc)),clsdb.__c.getField(true,"True"))) { 
 BA.debugLineNum = 26;BA.debugLine="ToastMessageShow($\"${disc} bestaat reeds\"$, True";
Debug.ShouldStop(33554432);
clsdb.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable(""),clsdb.__c.runMethod(true,"SmartStringFormatter",(Object)(BA.ObjectToString("")),(Object)((_disc))),RemoteObject.createImmutable(" bestaat reeds"))))),(Object)(clsdb.__c.getField(true,"True")));
 BA.debugLineNum = 27;BA.debugLine="Return";
Debug.ShouldStop(67108864);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 29;BA.debugLine="If disciId.Length > 8 Then";
Debug.ShouldStop(268435456);
if (RemoteObject.solveBoolean(">",_disciid.runMethod(true,"length"),BA.numberCast(double.class, 8))) { 
 BA.debugLineNum = 30;BA.debugLine="qry = \"update disciplines set discipline = ? whe";
Debug.ShouldStop(536870912);
__ref.setField ("_qry" /*RemoteObject*/ ,BA.ObjectToString("update disciplines set discipline = ? where id = ?"));
 BA.debugLineNum = 31;BA.debugLine="sql.ExecNonQuery2(qry, Array As String(disc, dis";
Debug.ShouldStop(1073741824);
__ref.getField(false,"_sql" /*RemoteObject*/ ).runVoidMethod ("ExecNonQuery2",(Object)(__ref.getField(true,"_qry" /*RemoteObject*/ )),(Object)(clsdb.__c.runMethod(false, "ArrayToList", (Object)(RemoteObject.createNewArray("String",new int[] {2},new Object[] {_disc,_disciid})))));
 }else {
 BA.debugLineNum = 33;BA.debugLine="disciId = Starter.clsFunc.UUIDv4";
Debug.ShouldStop(1);
_disciid = clsdb._starter._clsfunc /*RemoteObject*/ .runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_uuidv4" /*RemoteObject*/ );Debug.locals.put("disciId", _disciid);
 BA.debugLineNum = 34;BA.debugLine="qry = \"insert into disciplines (id, discipline)";
Debug.ShouldStop(2);
__ref.setField ("_qry" /*RemoteObject*/ ,BA.ObjectToString("insert into disciplines (id, discipline) values (?,?)"));
 BA.debugLineNum = 35;BA.debugLine="sql.ExecNonQuery2(qry, Array As String(disciId,";
Debug.ShouldStop(4);
__ref.getField(false,"_sql" /*RemoteObject*/ ).runVoidMethod ("ExecNonQuery2",(Object)(__ref.getField(true,"_qry" /*RemoteObject*/ )),(Object)(clsdb.__c.runMethod(false, "ArrayToList", (Object)(RemoteObject.createNewArray("String",new int[] {2},new Object[] {_disciid,_disc})))));
 };
 BA.debugLineNum = 39;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private db As String = $\"moyenne.db\"$";
clsdb._db = (RemoteObject.createImmutable("moyenne.db"));__ref.setField("_db",clsdb._db);
 //BA.debugLineNum = 3;BA.debugLine="Private sql As SQL";
clsdb._sql = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL");__ref.setField("_sql",clsdb._sql);
 //BA.debugLineNum = 4;BA.debugLine="Private curs As Cursor";
clsdb._curs = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");__ref.setField("_curs",clsdb._curs);
 //BA.debugLineNum = 5;BA.debugLine="Private qry As String";
clsdb._qry = RemoteObject.createImmutable("");__ref.setField("_qry",clsdb._qry);
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _closeconnection(RemoteObject __ref) throws Exception{
try {
		Debug.PushSubsStack("closeConnection (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,63);
if (RapidSub.canDelegate("closeconnection")) { return __ref.runUserSub(false, "clsdb","closeconnection", __ref);}
 BA.debugLineNum = 63;BA.debugLine="Sub closeConnection";
Debug.ShouldStop(1073741824);
 BA.debugLineNum = 64;BA.debugLine="If sql.IsInitialized Then";
Debug.ShouldStop(-2147483648);
if (__ref.getField(false,"_sql" /*RemoteObject*/ ).runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 65;BA.debugLine="sql.Close";
Debug.ShouldStop(1);
__ref.getField(false,"_sql" /*RemoteObject*/ ).runVoidMethod ("Close");
 };
 BA.debugLineNum = 67;BA.debugLine="If curs.IsInitialized Then";
Debug.ShouldStop(4);
if (__ref.getField(false,"_curs" /*RemoteObject*/ ).runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 68;BA.debugLine="curs.Close";
Debug.ShouldStop(8);
__ref.getField(false,"_curs" /*RemoteObject*/ ).runVoidMethod ("Close");
 };
 BA.debugLineNum = 70;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _deletediscipline(RemoteObject __ref,RemoteObject _id) throws Exception{
try {
		Debug.PushSubsStack("deleteDiscipline (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,41);
if (RapidSub.canDelegate("deletediscipline")) { return __ref.runUserSub(false, "clsdb","deletediscipline", __ref, _id);}
Debug.locals.put("id", _id);
 BA.debugLineNum = 41;BA.debugLine="Sub deleteDiscipline(id As String)";
Debug.ShouldStop(256);
 BA.debugLineNum = 42;BA.debugLine="initDb";
Debug.ShouldStop(512);
__ref.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_initdb" /*RemoteObject*/ );
 BA.debugLineNum = 43;BA.debugLine="qry = \"delete from disciplines where id=?\"";
Debug.ShouldStop(1024);
__ref.setField ("_qry" /*RemoteObject*/ ,BA.ObjectToString("delete from disciplines where id=?"));
 BA.debugLineNum = 44;BA.debugLine="sql.ExecNonQuery2(qry, Array As String(id))";
Debug.ShouldStop(2048);
__ref.getField(false,"_sql" /*RemoteObject*/ ).runVoidMethod ("ExecNonQuery2",(Object)(__ref.getField(true,"_qry" /*RemoteObject*/ )),(Object)(clsdb.__c.runMethod(false, "ArrayToList", (Object)(RemoteObject.createNewArray("String",new int[] {1},new Object[] {_id})))));
 BA.debugLineNum = 45;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _disciplineexists(RemoteObject __ref,RemoteObject _disc) throws Exception{
try {
		Debug.PushSubsStack("disciplineExists (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,50);
if (RapidSub.canDelegate("disciplineexists")) { return __ref.runUserSub(false, "clsdb","disciplineexists", __ref, _disc);}
Debug.locals.put("disc", _disc);
 BA.debugLineNum = 50;BA.debugLine="Sub disciplineExists(disc As String) As Boolean";
Debug.ShouldStop(131072);
 BA.debugLineNum = 51;BA.debugLine="initDb";
Debug.ShouldStop(262144);
__ref.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_initdb" /*RemoteObject*/ );
 BA.debugLineNum = 52;BA.debugLine="qry = \"select count(*) as result from disciplines";
Debug.ShouldStop(524288);
__ref.setField ("_qry" /*RemoteObject*/ ,BA.ObjectToString("select count(*) as result from disciplines where discipline = ?"));
 BA.debugLineNum = 53;BA.debugLine="curs = sql.ExecQuery2(qry, Array As String(disc))";
Debug.ShouldStop(1048576);
__ref.getField(false,"_curs" /*RemoteObject*/ ).setObject (__ref.getField(false,"_sql" /*RemoteObject*/ ).runMethod(false,"ExecQuery2",(Object)(__ref.getField(true,"_qry" /*RemoteObject*/ )),(Object)(RemoteObject.createNewArray("String",new int[] {1},new Object[] {_disc}))));
 BA.debugLineNum = 55;BA.debugLine="curs.Position = 0";
Debug.ShouldStop(4194304);
__ref.getField(false,"_curs" /*RemoteObject*/ ).runMethod(true,"setPosition",BA.numberCast(int.class, 0));
 BA.debugLineNum = 56;BA.debugLine="If curs.GetInt(\"result\") > 0 Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean(">",__ref.getField(false,"_curs" /*RemoteObject*/ ).runMethod(true,"GetInt",(Object)(RemoteObject.createImmutable("result"))),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 57;BA.debugLine="Return True";
Debug.ShouldStop(16777216);
if (true) return clsdb.__c.getField(true,"True");
 };
 BA.debugLineNum = 59;BA.debugLine="Return False";
Debug.ShouldStop(67108864);
if (true) return clsdb.__c.getField(true,"False");
 BA.debugLineNum = 60;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable(false);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _initdb(RemoteObject __ref) throws Exception{
try {
		Debug.PushSubsStack("initDb (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,16);
if (RapidSub.canDelegate("initdb")) { return __ref.runUserSub(false, "clsdb","initdb", __ref);}
 BA.debugLineNum = 16;BA.debugLine="Sub initDb";
Debug.ShouldStop(32768);
 BA.debugLineNum = 17;BA.debugLine="If sql.IsInitialized = False Then";
Debug.ShouldStop(65536);
if (RemoteObject.solveBoolean("=",__ref.getField(false,"_sql" /*RemoteObject*/ ).runMethod(true,"IsInitialized"),clsdb.__c.getField(true,"False"))) { 
 BA.debugLineNum = 18;BA.debugLine="sql.Initialize(Starter.share, db, False)";
Debug.ShouldStop(131072);
__ref.getField(false,"_sql" /*RemoteObject*/ ).runVoidMethod ("Initialize",(Object)(clsdb._starter._share /*RemoteObject*/ ),(Object)(__ref.getField(true,"_db" /*RemoteObject*/ )),(Object)(clsdb.__c.getField(true,"False")));
 };
 BA.debugLineNum = 20;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba) throws Exception{
try {
		Debug.PushSubsStack("Initialize (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,9);
if (RapidSub.canDelegate("initialize")) { return __ref.runUserSub(false, "clsdb","initialize", __ref, _ba);}
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
 BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize";
Debug.ShouldStop(256);
 BA.debugLineNum = 10;BA.debugLine="If File.Exists(Starter.share, db) = False Then";
Debug.ShouldStop(512);
if (RemoteObject.solveBoolean("=",clsdb.__c.getField(false,"File").runMethod(true,"Exists",(Object)(clsdb._starter._share /*RemoteObject*/ ),(Object)(__ref.getField(true,"_db" /*RemoteObject*/ ))),clsdb.__c.getField(true,"False"))) { 
 BA.debugLineNum = 11;BA.debugLine="File.Copy(File.DirAssets, db, Starter.share, db)";
Debug.ShouldStop(1024);
clsdb.__c.getField(false,"File").runVoidMethod ("Copy",(Object)(clsdb.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(__ref.getField(true,"_db" /*RemoteObject*/ )),(Object)(clsdb._starter._share /*RemoteObject*/ ),(Object)(__ref.getField(true,"_db" /*RemoteObject*/ )));
 };
 BA.debugLineNum = 13;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _lstdisciplines(RemoteObject __ref) throws Exception{
try {
		Debug.PushSubsStack("lstDisciplines (clsdb) ","clsdb",4,__ref.getField(false, "ba"),__ref,73);
if (RapidSub.canDelegate("lstdisciplines")) { return __ref.runUserSub(false, "clsdb","lstdisciplines", __ref);}
 BA.debugLineNum = 73;BA.debugLine="Sub lstDisciplines As Cursor";
Debug.ShouldStop(256);
 BA.debugLineNum = 74;BA.debugLine="initDb";
Debug.ShouldStop(512);
__ref.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_initdb" /*RemoteObject*/ );
 BA.debugLineNum = 75;BA.debugLine="qry = \"select discipline, id from disciplines ord";
Debug.ShouldStop(1024);
__ref.setField ("_qry" /*RemoteObject*/ ,BA.ObjectToString("select discipline, id from disciplines order by discipline"));
 BA.debugLineNum = 76;BA.debugLine="curs = sql.ExecQuery(qry)";
Debug.ShouldStop(2048);
__ref.getField(false,"_curs" /*RemoteObject*/ ).setObject (__ref.getField(false,"_sql" /*RemoteObject*/ ).runMethod(false,"ExecQuery",(Object)(__ref.getField(true,"_qry" /*RemoteObject*/ ))));
 BA.debugLineNum = 77;BA.debugLine="Return curs";
Debug.ShouldStop(4096);
if (true) return __ref.getField(false,"_curs" /*RemoteObject*/ );
 BA.debugLineNum = 79;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}