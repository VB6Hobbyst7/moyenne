package nl.pdeg.moyenne;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,27);
if (RapidSub.canDelegate("activity_create")) { return nl.pdeg.moyenne.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 27;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 30;BA.debugLine="StartActivity(discipline)";
Debug.ShouldStop(536870912);
main.mostCurrent.__c.runVoidMethod ("StartActivity",main.processBA,(Object)((main.mostCurrent._discipline.getObject())));
 BA.debugLineNum = 32;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,38);
if (RapidSub.canDelegate("activity_pause")) { return nl.pdeg.moyenne.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 38;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(32);
 BA.debugLineNum = 40;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,34);
if (RapidSub.canDelegate("activity_resume")) { return nl.pdeg.moyenne.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 34;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(2);
 BA.debugLineNum = 36;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
discipline_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.main");
starter.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.starter");
discipline.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.discipline");
clsfunctions.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.clsfunctions");
clsdb.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.clsdb");
animatedcounter.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.animatedcounter");
anotherprogressbar.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.anotherprogressbar");
b4xbreadcrumb.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xbreadcrumb");
b4xcolortemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xcolortemplate");
b4xcombobox.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xcombobox");
b4xdatetemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xdatetemplate");
b4xdialog.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xdialog");
b4xfloattextfield.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xfloattextfield");
b4xinputtemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xinputtemplate");
b4xlisttemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xlisttemplate");
b4xloadingindicator.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xloadingindicator");
b4xlongtexttemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xlongtexttemplate");
b4xplusminus.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xplusminus");
b4xsearchtemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xsearchtemplate");
b4xseekbar.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xseekbar");
b4xsignaturetemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xsignaturetemplate");
b4xswitch.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xswitch");
b4xtimedtemplate.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xtimedtemplate");
b4xformatter.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.b4xformatter");
roundslider.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.roundslider");
scrollinglabel.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.scrollinglabel");
swiftbutton.myClass = BA.getDeviceClass ("nl.pdeg.moyenne.swiftbutton");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}