package nl.pdeg.moyenne;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class discipline_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,29);
if (RapidSub.canDelegate("activity_create")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 29;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 31;BA.debugLine="Activity.LoadLayout(\"discipline\")";
Debug.ShouldStop(1073741824);
discipline.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("discipline")),discipline.mostCurrent.activityBA);
 BA.debugLineNum = 32;BA.debugLine="clsdbe.Initialize";
Debug.ShouldStop(-2147483648);
discipline.mostCurrent._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_initialize" /*RemoteObject*/ ,discipline.processBA);
 BA.debugLineNum = 33;BA.debugLine="clsFunc.Initialize";
Debug.ShouldStop(1);
discipline.mostCurrent._clsfunc.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_initialize" /*RemoteObject*/ ,discipline.processBA);
 BA.debugLineNum = 34;BA.debugLine="ime.Initialize(\"\")";
Debug.ShouldStop(2);
discipline.mostCurrent._ime.runVoidMethod ("Initialize",(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 35;BA.debugLine="createDisciplineList";
Debug.ShouldStop(4);
_createdisciplinelist();
 BA.debugLineNum = 36;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,44);
if (RapidSub.canDelegate("activity_pause")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 44;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(2048);
 BA.debugLineNum = 46;BA.debugLine="End Sub";
Debug.ShouldStop(8192);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,39);
if (RapidSub.canDelegate("activity_resume")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","activity_resume");}
 BA.debugLineNum = 39;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(64);
 BA.debugLineNum = 41;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _addedit(RemoteObject _edit,RemoteObject _label,RemoteObject _id) throws Exception{
try {
		Debug.PushSubsStack("addEdit (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,135);
if (RapidSub.canDelegate("addedit")) { nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","addedit", _edit, _label, _id); return;}
ResumableSub_addEdit rsub = new ResumableSub_addEdit(null,_edit,_label,_id);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_addEdit extends BA.ResumableSub {
public ResumableSub_addEdit(nl.pdeg.moyenne.discipline parent,RemoteObject _edit,RemoteObject _label,RemoteObject _id) {
this.parent = parent;
this._edit = _edit;
this._label = _label;
this._id = _id;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
nl.pdeg.moyenne.discipline parent;
RemoteObject _edit;
RemoteObject _label;
RemoteObject _id;
RemoteObject _sf = RemoteObject.declareNull("Object");
RemoteObject _pnl = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
RemoteObject _result = RemoteObject.createImmutable(0);

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("addEdit (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,135);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("edit", _edit);
Debug.locals.put("label", _label);
Debug.locals.put("id", _id);
 BA.debugLineNum = 137;BA.debugLine="Dim sf As Object = DetailsDialog.ShowAsync(\"\", \"B";
Debug.ShouldStop(256);
_sf = parent.mostCurrent._detailsdialog.runMethod(false,"ShowAsync",(Object)(BA.ObjectToString("")),(Object)(BA.ObjectToString("Bewaar")),(Object)(BA.ObjectToString("Annuleer")),(Object)(BA.ObjectToString("")),discipline.mostCurrent.activityBA,(Object)((parent.mostCurrent.__c.getField(false,"Null"))),(Object)(parent.mostCurrent.__c.getField(true,"True")));Debug.locals.put("sf", _sf);Debug.locals.put("sf", _sf);
 BA.debugLineNum = 138;BA.debugLine="DetailsDialog.SetSize(100%X, 250dip)";
Debug.ShouldStop(512);
parent.mostCurrent._detailsdialog.runVoidMethod ("SetSize",(Object)(parent.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),discipline.mostCurrent.activityBA)),(Object)(parent.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250)))));
 BA.debugLineNum = 139;BA.debugLine="Wait For (sf) Dialog_Ready(pnl As Panel)";
Debug.ShouldStop(1024);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","dialog_ready", discipline.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "discipline", "addedit"), _sf);
this.state = 17;
return;
case 17:
//C
this.state = 1;
_pnl = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("pnl", _pnl);
;
 BA.debugLineNum = 140;BA.debugLine="pnl.LoadLayout(\"discipline_edit\")";
Debug.ShouldStop(2048);
_pnl.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("discipline_edit")),discipline.mostCurrent.activityBA);
 BA.debugLineNum = 141;BA.debugLine="txt_discipline_edit.Text = label.Text";
Debug.ShouldStop(4096);
parent.mostCurrent._txt_discipline_edit.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(_label.runMethod(true,"getText")));
 BA.debugLineNum = 142;BA.debugLine="txt_discipline_edit.Enabled = True";
Debug.ShouldStop(8192);
parent.mostCurrent._txt_discipline_edit.runMethod(true,"setEnabled",parent.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 143;BA.debugLine="If edit = False Then";
Debug.ShouldStop(16384);
if (true) break;

case 1:
//if
this.state = 4;
if (RemoteObject.solveBoolean("=",_edit,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 144;BA.debugLine="txt_discipline_edit.Hint = \"Nieuwe discipline\"";
Debug.ShouldStop(32768);
parent.mostCurrent._txt_discipline_edit.runMethod(true,"setHint",BA.ObjectToString("Nieuwe discipline"));
 if (true) break;

case 4:
//C
this.state = 5;
;
 BA.debugLineNum = 146;BA.debugLine="txt_discipline_edit.RequestFocus";
Debug.ShouldStop(131072);
parent.mostCurrent._txt_discipline_edit.runVoidMethod ("RequestFocus");
 BA.debugLineNum = 147;BA.debugLine="Wait For (sf) Dialog_Result(result As Int)";
Debug.ShouldStop(262144);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","dialog_result", discipline.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "discipline", "addedit"), _sf);
this.state = 18;
return;
case 18:
//C
this.state = 5;
_result = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("result", _result);
;
 BA.debugLineNum = 149;BA.debugLine="If result = DialogResponse.POSITIVE Then";
Debug.ShouldStop(1048576);
if (true) break;

case 5:
//if
this.state = 16;
if (RemoteObject.solveBoolean("=",_result,BA.numberCast(double.class, parent.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"POSITIVE")))) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 BA.debugLineNum = 150;BA.debugLine="label.Text = txt_discipline_edit.Text";
Debug.ShouldStop(2097152);
_label.runMethod(true,"setText",BA.ObjectToCharSequence(parent.mostCurrent._txt_discipline_edit.runMethod(true,"getText")));
 BA.debugLineNum = 151;BA.debugLine="If edit = False Then";
Debug.ShouldStop(4194304);
if (true) break;

case 8:
//if
this.state = 11;
if (RemoteObject.solveBoolean("=",_edit,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 BA.debugLineNum = 152;BA.debugLine="id = \"\"";
Debug.ShouldStop(8388608);
_id = BA.ObjectToString("");Debug.locals.put("id", _id);
 if (true) break;

case 11:
//C
this.state = 12;
;
 BA.debugLineNum = 154;BA.debugLine="clsdbe.addDiscipline(txt_discipline_edit.Text, i";
Debug.ShouldStop(33554432);
parent.mostCurrent._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_adddiscipline" /*RemoteObject*/ ,(Object)(parent.mostCurrent._txt_discipline_edit.runMethod(true,"getText")),(Object)(_id));
 BA.debugLineNum = 155;BA.debugLine="If edit = False Then";
Debug.ShouldStop(67108864);
if (true) break;

case 12:
//if
this.state = 15;
if (RemoteObject.solveBoolean("=",_edit,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 14;
}if (true) break;

case 14:
//C
this.state = 15;
 BA.debugLineNum = 156;BA.debugLine="createDisciplineList";
Debug.ShouldStop(134217728);
_createdisciplinelist();
 if (true) break;

case 15:
//C
this.state = 16;
;
 if (true) break;

case 16:
//C
this.state = -1;
;
 BA.debugLineNum = 159;BA.debugLine="ime.HideKeyboard";
Debug.ShouldStop(1073741824);
parent.mostCurrent._ime.runVoidMethod ("HideKeyboard",discipline.mostCurrent.activityBA);
 BA.debugLineNum = 160;BA.debugLine="countDisciplines";
Debug.ShouldStop(-2147483648);
_countdisciplines();
 BA.debugLineNum = 161;BA.debugLine="End Sub";
Debug.ShouldStop(1);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _dialog_ready(RemoteObject _pnl) throws Exception{
}
public static void  _dialog_result(RemoteObject _result) throws Exception{
}
public static RemoteObject  _countdisciplines() throws Exception{
try {
		Debug.PushSubsStack("countDisciplines (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,163);
if (RapidSub.canDelegate("countdisciplines")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","countdisciplines");}
 BA.debugLineNum = 163;BA.debugLine="Sub countDisciplines";
Debug.ShouldStop(4);
 BA.debugLineNum = 164;BA.debugLine="lbl_disciplines_found.Text = $\"Disciplines (${clv";
Debug.ShouldStop(8);
discipline.mostCurrent._lbl_disciplines_found.runMethod(true,"setText",BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable("Disciplines ("),discipline.mostCurrent.__c.runMethod(true,"SmartStringFormatter",(Object)(BA.ObjectToString("")),(Object)((discipline.mostCurrent._clv_discipline.runMethod(true,"_getsize")))),RemoteObject.createImmutable(")")))));
 BA.debugLineNum = 165;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _createdisciplinelist() throws Exception{
try {
		Debug.PushSubsStack("createDisciplineList (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,54);
if (RapidSub.canDelegate("createdisciplinelist")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","createdisciplinelist");}
int _i = 0;
 BA.debugLineNum = 54;BA.debugLine="Sub createDisciplineList";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 55;BA.debugLine="curs = Starter.clsDbe.lstDisciplines";
Debug.ShouldStop(4194304);
discipline._curs = discipline.mostCurrent._starter._clsdbe /*RemoteObject*/ .runClassMethod (nl.pdeg.moyenne.clsdb.class, "_lstdisciplines" /*RemoteObject*/ );
 BA.debugLineNum = 56;BA.debugLine="clsdbe.closeConnection";
Debug.ShouldStop(8388608);
discipline.mostCurrent._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_closeconnection" /*RemoteObject*/ );
 BA.debugLineNum = 57;BA.debugLine="clv_discipline.Clear";
Debug.ShouldStop(16777216);
discipline.mostCurrent._clv_discipline.runVoidMethod ("_clear");
 BA.debugLineNum = 58;BA.debugLine="curs.Position = 0";
Debug.ShouldStop(33554432);
discipline._curs.runMethod(true,"setPosition",BA.numberCast(int.class, 0));
 BA.debugLineNum = 60;BA.debugLine="For i = 0 To curs.RowCount - 1";
Debug.ShouldStop(134217728);
{
final int step5 = 1;
final int limit5 = RemoteObject.solve(new RemoteObject[] {discipline._curs.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step5 > 0 && _i <= limit5) || (step5 < 0 && _i >= limit5) ;_i = ((int)(0 + _i + step5))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 61;BA.debugLine="curs.Position = i";
Debug.ShouldStop(268435456);
discipline._curs.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 62;BA.debugLine="clv_discipline.Add(genDisciplineList(curs.GetStr";
Debug.ShouldStop(536870912);
discipline.mostCurrent._clv_discipline.runVoidMethod ("_add",RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.B4XViewWrapper"), _gendisciplinelist(discipline._curs.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("discipline"))),discipline._curs.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("id"))),discipline.mostCurrent._clv_discipline.runMethod(false,"_asview").runMethod(true,"getWidth")).getObject()),(Object)((RemoteObject.createImmutable(""))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 64;BA.debugLine="curs.Close";
Debug.ShouldStop(-2147483648);
discipline._curs.runVoidMethod ("Close");
 BA.debugLineNum = 65;BA.debugLine="countDisciplines";
Debug.ShouldStop(1);
_countdisciplines();
 BA.debugLineNum = 66;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _gendisciplinelist(RemoteObject _disci,RemoteObject _id,RemoteObject _width) throws Exception{
try {
		Debug.PushSubsStack("genDisciplineList (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,69);
if (RapidSub.canDelegate("gendisciplinelist")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","gendisciplinelist", _disci, _id, _width);}
RemoteObject _p = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
Debug.locals.put("disci", _disci);
Debug.locals.put("id", _id);
Debug.locals.put("width", _width);
 BA.debugLineNum = 69;BA.debugLine="Sub genDisciplineList(disci As String, id As Strin";
Debug.ShouldStop(16);
 BA.debugLineNum = 70;BA.debugLine="Dim p As Panel";
Debug.ShouldStop(32);
_p = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");Debug.locals.put("p", _p);
 BA.debugLineNum = 71;BA.debugLine="p.Initialize(\"\")";
Debug.ShouldStop(64);
_p.runVoidMethod ("Initialize",discipline.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 72;BA.debugLine="p.SetLayout(0,0, width, 185dip)";
Debug.ShouldStop(128);
_p.runVoidMethod ("SetLayout",(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 0)),(Object)(_width),(Object)(discipline.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 185)))));
 BA.debugLineNum = 74;BA.debugLine="p.LoadLayout(\"clv_discipline\")";
Debug.ShouldStop(512);
_p.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("clv_discipline")),discipline.mostCurrent.activityBA);
 BA.debugLineNum = 75;BA.debugLine="lbl_discipline_header.Text = disci";
Debug.ShouldStop(1024);
discipline.mostCurrent._lbl_discipline_header.runMethod(true,"setText",BA.ObjectToCharSequence(_disci));
 BA.debugLineNum = 76;BA.debugLine="lbl_discipline_header.Tag = \"disci\"";
Debug.ShouldStop(2048);
discipline.mostCurrent._lbl_discipline_header.runMethod(false,"setTag",RemoteObject.createImmutable(("disci")));
 BA.debugLineNum = 77;BA.debugLine="p.Tag = id";
Debug.ShouldStop(4096);
_p.runMethod(false,"setTag",(_id));
 BA.debugLineNum = 78;BA.debugLine="Return p";
Debug.ShouldStop(8192);
if (true) return _p;
 BA.debugLineNum = 79;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 13;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 14;BA.debugLine="Private ime As IME";
discipline.mostCurrent._ime = RemoteObject.createNew ("anywheresoftware.b4a.objects.IME");
 //BA.debugLineNum = 15;BA.debugLine="Private pnl_discipline As Panel";
discipline.mostCurrent._pnl_discipline = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 16;BA.debugLine="Private lbl_discipline_header As Label";
discipline.mostCurrent._lbl_discipline_header = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 17;BA.debugLine="Private clsdbe As clsDb";
discipline.mostCurrent._clsdbe = RemoteObject.createNew ("nl.pdeg.moyenne.clsdb");
 //BA.debugLineNum = 18;BA.debugLine="Private clsFunc As clsFunctions";
discipline.mostCurrent._clsfunc = RemoteObject.createNew ("nl.pdeg.moyenne.clsfunctions");
 //BA.debugLineNum = 19;BA.debugLine="Private clv_discipline As CustomListView";
discipline.mostCurrent._clv_discipline = RemoteObject.createNew ("b4a.example3.customlistview");
 //BA.debugLineNum = 20;BA.debugLine="Private lbl_delete As Label";
discipline.mostCurrent._lbl_delete = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 21;BA.debugLine="Private DetailsDialog As CustomLayoutDialog";
discipline.mostCurrent._detailsdialog = RemoteObject.createNew ("anywheresoftware.b4a.agraham.dialogs.InputDialog.CustomLayoutDialog");
 //BA.debugLineNum = 22;BA.debugLine="Private txt_discipline_edit As EditText";
discipline.mostCurrent._txt_discipline_edit = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 23;BA.debugLine="Private lbl_edit As Label";
discipline.mostCurrent._lbl_edit = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 24;BA.debugLine="Private lbl_add As Label";
discipline.mostCurrent._lbl_add = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 25;BA.debugLine="Private lbl_disciplines_found As Label";
discipline.mostCurrent._lbl_disciplines_found = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _lbl_add_click() throws Exception{
try {
		Debug.PushSubsStack("lbl_add_Click (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,167);
if (RapidSub.canDelegate("lbl_add_click")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","lbl_add_click");}
RemoteObject _label = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
 BA.debugLineNum = 167;BA.debugLine="Sub lbl_add_Click";
Debug.ShouldStop(64);
 BA.debugLineNum = 168;BA.debugLine="Dim label As Label";
Debug.ShouldStop(128);
_label = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");Debug.locals.put("label", _label);
 BA.debugLineNum = 169;BA.debugLine="label.Initialize(\"\")";
Debug.ShouldStop(256);
_label.runVoidMethod ("Initialize",discipline.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 170;BA.debugLine="addEdit(False, label, \"\")";
Debug.ShouldStop(512);
_addedit(discipline.mostCurrent.__c.getField(true,"False"),_label,RemoteObject.createImmutable(""));
 BA.debugLineNum = 171;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _lbl_delete_click() throws Exception{
try {
		Debug.PushSubsStack("lbl_delete_Click (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,111);
if (RapidSub.canDelegate("lbl_delete_click")) { nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","lbl_delete_click"); return;}
ResumableSub_lbl_delete_Click rsub = new ResumableSub_lbl_delete_Click(null);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_lbl_delete_Click extends BA.ResumableSub {
public ResumableSub_lbl_delete_Click(nl.pdeg.moyenne.discipline parent) {
this.parent = parent;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
nl.pdeg.moyenne.discipline parent;
RemoteObject _index = RemoteObject.createImmutable(0);
RemoteObject _response = RemoteObject.createImmutable(0);

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("lbl_delete_Click (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,111);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 BA.debugLineNum = 112;BA.debugLine="Dim index As Int = clsFunc.colorHeader(clv_discip";
Debug.ShouldStop(32768);
_index = parent.mostCurrent._clsfunc.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_colorheader" /*RemoteObject*/ ,(Object)(parent.mostCurrent._clv_discipline),(Object)(parent.mostCurrent.__c.runMethod(false,"Sender",discipline.mostCurrent.activityBA)));Debug.locals.put("index", _index);Debug.locals.put("index", _index);
 BA.debugLineNum = 114;BA.debugLine="Msgbox2Async($\"Geselecteerde discipline verwijder";
Debug.ShouldStop(131072);
parent.mostCurrent.__c.runVoidMethod ("Msgbox2Async",(Object)(BA.ObjectToCharSequence((RemoteObject.createImmutable("Geselecteerde discipline verwijderen?")))),(Object)(BA.ObjectToCharSequence(parent.mostCurrent.__c.getField(false,"Application").runMethod(true,"getLabelName"))),(Object)(BA.ObjectToString("Ja")),(Object)(BA.ObjectToString("")),(Object)(BA.ObjectToString("Nee")),RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper"), parent.mostCurrent.__c.getField(false,"Null")),discipline.processBA,(Object)(parent.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 116;BA.debugLine="Wait For Msgbox_Result (response As Int)";
Debug.ShouldStop(524288);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","msgbox_result", discipline.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "discipline", "lbl_delete_click"), null);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_response = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("response", _response);
;
 BA.debugLineNum = 118;BA.debugLine="If response = DialogResponse.POSITIVE Then";
Debug.ShouldStop(2097152);
if (true) break;

case 1:
//if
this.state = 4;
if (RemoteObject.solveBoolean("=",_response,BA.numberCast(double.class, parent.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"POSITIVE")))) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 119;BA.debugLine="removeItem(index)";
Debug.ShouldStop(4194304);
_removeitem(_index);
 if (true) break;

case 4:
//C
this.state = -1;
;
 BA.debugLineNum = 121;BA.debugLine="countDisciplines";
Debug.ShouldStop(16777216);
_countdisciplines();
 BA.debugLineNum = 122;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _msgbox_result(RemoteObject _response) throws Exception{
}
public static RemoteObject  _lbl_discipline_header_click() throws Exception{
try {
		Debug.PushSubsStack("lbl_discipline_header_Click (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,82);
if (RapidSub.canDelegate("lbl_discipline_header_click")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","lbl_discipline_header_click");}
 BA.debugLineNum = 82;BA.debugLine="Sub lbl_discipline_header_Click";
Debug.ShouldStop(131072);
 BA.debugLineNum = 83;BA.debugLine="clsFunc.colorHeader(clv_discipline, Sender)";
Debug.ShouldStop(262144);
discipline.mostCurrent._clsfunc.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_colorheader" /*RemoteObject*/ ,(Object)(discipline.mostCurrent._clv_discipline),(Object)(discipline.mostCurrent.__c.runMethod(false,"Sender",discipline.mostCurrent.activityBA)));
 BA.debugLineNum = 85;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _lbl_edit_click() throws Exception{
try {
		Debug.PushSubsStack("lbl_edit_Click (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,88);
if (RapidSub.canDelegate("lbl_edit_click")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","lbl_edit_click");}
RemoteObject _index = RemoteObject.createImmutable(0);
RemoteObject _pnl = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
RemoteObject _id = RemoteObject.createImmutable("");
RemoteObject _label = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
RemoteObject _lbl = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
 BA.debugLineNum = 88;BA.debugLine="Sub lbl_edit_Click";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 89;BA.debugLine="Dim index As Int =clsFunc.colorHeader(clv_discipl";
Debug.ShouldStop(16777216);
_index = discipline.mostCurrent._clsfunc.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_colorheader" /*RemoteObject*/ ,(Object)(discipline.mostCurrent._clv_discipline),(Object)(discipline.mostCurrent.__c.runMethod(false,"Sender",discipline.mostCurrent.activityBA)));Debug.locals.put("index", _index);Debug.locals.put("index", _index);
 BA.debugLineNum = 90;BA.debugLine="Dim pnl As Panel = clv_discipline.GetPanel(index)";
Debug.ShouldStop(33554432);
_pnl = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
_pnl.setObject(discipline.mostCurrent._clv_discipline.runMethod(false,"_getpanel",(Object)(_index)).getObject());Debug.locals.put("pnl", _pnl);
 BA.debugLineNum = 91;BA.debugLine="Dim id As  String = pnl.Tag";
Debug.ShouldStop(67108864);
_id = BA.ObjectToString(_pnl.runMethod(false,"getTag"));Debug.locals.put("id", _id);Debug.locals.put("id", _id);
 BA.debugLineNum = 92;BA.debugLine="Dim label As Label";
Debug.ShouldStop(134217728);
_label = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");Debug.locals.put("label", _label);
 BA.debugLineNum = 94;BA.debugLine="For Each lbl As View In pnl.GetAllViewsRecursive";
Debug.ShouldStop(536870912);
_lbl = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");
{
final RemoteObject group5 = _pnl.runMethod(false,"GetAllViewsRecursive");
final int groupLen5 = group5.runMethod(true,"getSize").<Integer>get()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_lbl.setObject(group5.runMethod(false,"Get",index5));
Debug.locals.put("lbl", _lbl);
 BA.debugLineNum = 95;BA.debugLine="If lbl.Tag = \"disci\" Then";
Debug.ShouldStop(1073741824);
if (RemoteObject.solveBoolean("=",_lbl.runMethod(false,"getTag"),RemoteObject.createImmutable(("disci")))) { 
 BA.debugLineNum = 96;BA.debugLine="label = lbl";
Debug.ShouldStop(-2147483648);
_label.setObject(_lbl.getObject());
 BA.debugLineNum = 97;BA.debugLine="Exit";
Debug.ShouldStop(1);
if (true) break;
 };
 }
}Debug.locals.put("lbl", _lbl);
;
 BA.debugLineNum = 100;BA.debugLine="addEdit(True, label, id)";
Debug.ShouldStop(8);
_addedit(discipline.mostCurrent.__c.getField(true,"True"),_label,_id);
 BA.debugLineNum = 103;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _pnl_discipline_click() throws Exception{
try {
		Debug.PushSubsStack("pnl_discipline_Click (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,106);
if (RapidSub.canDelegate("pnl_discipline_click")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","pnl_discipline_click");}
 BA.debugLineNum = 106;BA.debugLine="Sub pnl_discipline_Click";
Debug.ShouldStop(512);
 BA.debugLineNum = 107;BA.debugLine="clsFunc.colorHeader(clv_discipline, Sender)";
Debug.ShouldStop(1024);
discipline.mostCurrent._clsfunc.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_colorheader" /*RemoteObject*/ ,(Object)(discipline.mostCurrent._clv_discipline),(Object)(discipline.mostCurrent.__c.runMethod(false,"Sender",discipline.mostCurrent.activityBA)));
 BA.debugLineNum = 108;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private curs As Cursor";
discipline._curs = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _removeitem(RemoteObject _index) throws Exception{
try {
		Debug.PushSubsStack("removeItem (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,125);
if (RapidSub.canDelegate("removeitem")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","removeitem", _index);}
RemoteObject _pnl = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
RemoteObject _id = RemoteObject.createImmutable("");
Debug.locals.put("index", _index);
 BA.debugLineNum = 125;BA.debugLine="Sub removeItem(index As Int)";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 126;BA.debugLine="Dim pnl As Panel = clv_discipline.GetPanel(index)";
Debug.ShouldStop(536870912);
_pnl = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
_pnl.setObject(discipline.mostCurrent._clv_discipline.runMethod(false,"_getpanel",(Object)(_index)).getObject());Debug.locals.put("pnl", _pnl);
 BA.debugLineNum = 127;BA.debugLine="Dim id As String = pnl.Tag";
Debug.ShouldStop(1073741824);
_id = BA.ObjectToString(_pnl.runMethod(false,"getTag"));Debug.locals.put("id", _id);Debug.locals.put("id", _id);
 BA.debugLineNum = 129;BA.debugLine="clsdbe.deleteDiscipline(id)";
Debug.ShouldStop(1);
discipline.mostCurrent._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_deletediscipline" /*RemoteObject*/ ,(Object)(_id));
 BA.debugLineNum = 130;BA.debugLine="clsdbe.closeConnection";
Debug.ShouldStop(2);
discipline.mostCurrent._clsdbe.runClassMethod (nl.pdeg.moyenne.clsdb.class, "_closeconnection" /*RemoteObject*/ );
 BA.debugLineNum = 131;BA.debugLine="clv_discipline.RemoveAt(index)";
Debug.ShouldStop(4);
discipline.mostCurrent._clv_discipline.runVoidMethod ("_removeat",(Object)(_index));
 BA.debugLineNum = 132;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _txt_discipline_focuschanged(RemoteObject _hasfocus) throws Exception{
try {
		Debug.PushSubsStack("txt_discipline_FocusChanged (discipline) ","discipline",2,discipline.mostCurrent.activityBA,discipline.mostCurrent,49);
if (RapidSub.canDelegate("txt_discipline_focuschanged")) { return nl.pdeg.moyenne.discipline.remoteMe.runUserSub(false, "discipline","txt_discipline_focuschanged", _hasfocus);}
Debug.locals.put("HasFocus", _hasfocus);
 BA.debugLineNum = 49;BA.debugLine="Sub txt_discipline_FocusChanged (HasFocus As Boole";
Debug.ShouldStop(65536);
 BA.debugLineNum = 51;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}