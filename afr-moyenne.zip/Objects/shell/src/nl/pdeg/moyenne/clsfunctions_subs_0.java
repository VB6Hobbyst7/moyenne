package nl.pdeg.moyenne;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class clsfunctions_subs_0 {


public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Dim clvHeaderPrimaryColor As String =  0xFF05B80A";
clsfunctions._clvheaderprimarycolor = BA.NumberToString(0xff05b80a);__ref.setField("_clvheaderprimarycolor",clsfunctions._clvheaderprimarycolor);
 //BA.debugLineNum = 3;BA.debugLine="Dim clvHeaderHighlightColor As String =  0xFF0059";
clsfunctions._clvheaderhighlightcolor = BA.NumberToString(0xff0059ff);__ref.setField("_clvheaderhighlightcolor",clsfunctions._clvheaderhighlightcolor);
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _colorheader(RemoteObject __ref,RemoteObject _clv,RemoteObject _sndr) throws Exception{
try {
		Debug.PushSubsStack("colorHeader (clsfunctions) ","clsfunctions",3,__ref.getField(false, "ba"),__ref,35);
if (RapidSub.canDelegate("colorheader")) { return __ref.runUserSub(false, "clsfunctions","colorheader", __ref, _clv, _sndr);}
RemoteObject _maxindex = RemoteObject.createImmutable(0);
RemoteObject _index = RemoteObject.createImmutable(0);
RemoteObject _pnl = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
int _i = 0;
RemoteObject _v = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
Debug.locals.put("clv", _clv);
Debug.locals.put("sndr", _sndr);
 BA.debugLineNum = 35;BA.debugLine="Sub colorHeader(clv As CustomListView, sndr As Obj";
Debug.ShouldStop(4);
 BA.debugLineNum = 37;BA.debugLine="Dim maxIndex As Int = clv.GetSize";
Debug.ShouldStop(16);
_maxindex = _clv.runMethod(true,"_getsize");Debug.locals.put("maxIndex", _maxindex);Debug.locals.put("maxIndex", _maxindex);
 BA.debugLineNum = 38;BA.debugLine="Dim index As Int = getPanelIndex(clv, sndr)";
Debug.ShouldStop(32);
_index = __ref.runClassMethod (nl.pdeg.moyenne.clsfunctions.class, "_getpanelindex" /*RemoteObject*/ ,(Object)(_clv),(Object)(_sndr));Debug.locals.put("index", _index);Debug.locals.put("index", _index);
 BA.debugLineNum = 39;BA.debugLine="Dim pnl As Panel";
Debug.ShouldStop(64);
_pnl = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");Debug.locals.put("pnl", _pnl);
 BA.debugLineNum = 41;BA.debugLine="For i = 0 To maxIndex - 1";
Debug.ShouldStop(256);
{
final int step4 = 1;
final int limit4 = RemoteObject.solve(new RemoteObject[] {_maxindex,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step4 > 0 && _i <= limit4) || (step4 < 0 && _i >= limit4) ;_i = ((int)(0 + _i + step4))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 42;BA.debugLine="pnl = clv.GetPanel(i)";
Debug.ShouldStop(512);
_pnl.setObject(_clv.runMethod(false,"_getpanel",(Object)(BA.numberCast(int.class, _i))).getObject());
 BA.debugLineNum = 44;BA.debugLine="For Each v As View In pnl.GetAllViewsRecursive";
Debug.ShouldStop(2048);
_v = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");
{
final RemoteObject group6 = _pnl.runMethod(false,"GetAllViewsRecursive");
final int groupLen6 = group6.runMethod(true,"getSize").<Integer>get()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_v.setObject(group6.runMethod(false,"Get",index6));
Debug.locals.put("v", _v);
 BA.debugLineNum = 45;BA.debugLine="If v Is Label Then";
Debug.ShouldStop(4096);
if (RemoteObject.solveBoolean("i",_v.getObjectOrNull(), RemoteObject.createImmutable("android.widget.TextView"))) { 
 BA.debugLineNum = 46;BA.debugLine="If v.Tag = \"disci\" Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",_v.runMethod(false,"getTag"),RemoteObject.createImmutable(("disci")))) { 
 BA.debugLineNum = 47;BA.debugLine="v.Color = clvHeaderPrimaryColor";
Debug.ShouldStop(16384);
_v.runVoidMethod ("setColor",BA.numberCast(int.class, __ref.getField(true,"_clvheaderprimarycolor" /*RemoteObject*/ )));
 BA.debugLineNum = 48;BA.debugLine="If i = index Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",RemoteObject.createImmutable(_i),BA.numberCast(double.class, _index))) { 
 BA.debugLineNum = 49;BA.debugLine="v.Color = clvHeaderHighlightColor";
Debug.ShouldStop(65536);
_v.runVoidMethod ("setColor",BA.numberCast(int.class, __ref.getField(true,"_clvheaderhighlightcolor" /*RemoteObject*/ )));
 };
 };
 };
 }
}Debug.locals.put("v", _v);
;
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 56;BA.debugLine="Return index";
Debug.ShouldStop(8388608);
if (true) return _index;
 BA.debugLineNum = 58;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable(0);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _getpanelindex(RemoteObject __ref,RemoteObject _clv,RemoteObject _sndr) throws Exception{
try {
		Debug.PushSubsStack("getPanelIndex (clsfunctions) ","clsfunctions",3,__ref.getField(false, "ba"),__ref,29);
if (RapidSub.canDelegate("getpanelindex")) { return __ref.runUserSub(false, "clsfunctions","getpanelindex", __ref, _clv, _sndr);}
Debug.locals.put("clv", _clv);
Debug.locals.put("sndr", _sndr);
 BA.debugLineNum = 29;BA.debugLine="Sub getPanelIndex(clv As CustomListView, sndr As O";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 30;BA.debugLine="Return clv.GetItemFromView(sndr)";
Debug.ShouldStop(536870912);
if (true) return _clv.runMethod(true,"_getitemfromview",RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.B4XViewWrapper"), _sndr));
 BA.debugLineNum = 31;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable(0);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba) throws Exception{
try {
		Debug.PushSubsStack("Initialize (clsfunctions) ","clsfunctions",3,__ref.getField(false, "ba"),__ref,7);
if (RapidSub.canDelegate("initialize")) { return __ref.runUserSub(false, "clsfunctions","initialize", __ref, _ba);}
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
 BA.debugLineNum = 7;BA.debugLine="Public Sub Initialize";
Debug.ShouldStop(64);
 BA.debugLineNum = 9;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _uuidv4(RemoteObject __ref) throws Exception{
try {
		Debug.PushSubsStack("UUIDv4 (clsfunctions) ","clsfunctions",3,__ref.getField(false, "ba"),__ref,12);
if (RapidSub.canDelegate("uuidv4")) { return __ref.runUserSub(false, "clsfunctions","uuidv4", __ref);}
RemoteObject _sb = RemoteObject.declareNull("anywheresoftware.b4a.keywords.StringBuilderWrapper");
RemoteObject _stp = RemoteObject.createImmutable(0);
int _n = 0;
RemoteObject _c = RemoteObject.createImmutable(0);
 BA.debugLineNum = 12;BA.debugLine="Sub UUIDv4 As String";
Debug.ShouldStop(2048);
 BA.debugLineNum = 13;BA.debugLine="Dim sb As StringBuilder";
Debug.ShouldStop(4096);
_sb = RemoteObject.createNew ("anywheresoftware.b4a.keywords.StringBuilderWrapper");Debug.locals.put("sb", _sb);
 BA.debugLineNum = 14;BA.debugLine="sb.Initialize";
Debug.ShouldStop(8192);
_sb.runVoidMethod ("Initialize");
 BA.debugLineNum = 15;BA.debugLine="For Each stp As Int In Array(8, 4, 4, 4, 12)";
Debug.ShouldStop(16384);
{
final RemoteObject group3 = RemoteObject.createNewArray("Object",new int[] {5},new Object[] {RemoteObject.createImmutable((8)),RemoteObject.createImmutable((4)),RemoteObject.createImmutable((4)),RemoteObject.createImmutable((4)),RemoteObject.createImmutable((12))});
final int groupLen3 = group3.getField(true,"length").<Integer>get()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_stp = BA.numberCast(int.class, group3.getArrayElement(false,RemoteObject.createImmutable(index3)));Debug.locals.put("stp", _stp);
Debug.locals.put("stp", _stp);
 BA.debugLineNum = 16;BA.debugLine="If sb.Length > 0 Then sb.Append(\"-\")";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean(">",_sb.runMethod(true,"getLength"),BA.numberCast(double.class, 0))) { 
_sb.runVoidMethod ("Append",(Object)(RemoteObject.createImmutable("-")));};
 BA.debugLineNum = 17;BA.debugLine="For n = 1 To stp";
Debug.ShouldStop(65536);
{
final int step5 = 1;
final int limit5 = _stp.<Integer>get().intValue();
_n = 1 ;
for (;(step5 > 0 && _n <= limit5) || (step5 < 0 && _n >= limit5) ;_n = ((int)(0 + _n + step5))  ) {
Debug.locals.put("n", _n);
 BA.debugLineNum = 18;BA.debugLine="Dim c As Int = Rnd(0, 16)";
Debug.ShouldStop(131072);
_c = clsfunctions.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 16)));Debug.locals.put("c", _c);Debug.locals.put("c", _c);
 BA.debugLineNum = 19;BA.debugLine="If c < 10 Then c = c + 48 Else c = c + 55";
Debug.ShouldStop(262144);
if (RemoteObject.solveBoolean("<",_c,BA.numberCast(double.class, 10))) { 
_c = RemoteObject.solve(new RemoteObject[] {_c,RemoteObject.createImmutable(48)}, "+",1, 1);Debug.locals.put("c", _c);}
else {
_c = RemoteObject.solve(new RemoteObject[] {_c,RemoteObject.createImmutable(55)}, "+",1, 1);Debug.locals.put("c", _c);};
 BA.debugLineNum = 20;BA.debugLine="If sb.Length = 19 Then c = Asc(\"8\")";
Debug.ShouldStop(524288);
if (RemoteObject.solveBoolean("=",_sb.runMethod(true,"getLength"),BA.numberCast(double.class, 19))) { 
_c = clsfunctions.__c.runMethod(true,"Asc",(Object)(BA.ObjectToChar(RemoteObject.createImmutable("8"))));Debug.locals.put("c", _c);};
 BA.debugLineNum = 21;BA.debugLine="If sb.Length = 14 Then c = Asc(\"4\")";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean("=",_sb.runMethod(true,"getLength"),BA.numberCast(double.class, 14))) { 
_c = clsfunctions.__c.runMethod(true,"Asc",(Object)(BA.ObjectToChar(RemoteObject.createImmutable("4"))));Debug.locals.put("c", _c);};
 BA.debugLineNum = 22;BA.debugLine="sb.Append(Chr(c))";
Debug.ShouldStop(2097152);
_sb.runVoidMethod ("Append",(Object)(BA.ObjectToString(clsfunctions.__c.runMethod(true,"Chr",(Object)(_c)))));
 }
}Debug.locals.put("n", _n);
;
 }
}Debug.locals.put("stp", _stp);
;
 BA.debugLineNum = 25;BA.debugLine="Return sb.ToString.ToLowerCase";
Debug.ShouldStop(16777216);
if (true) return _sb.runMethod(true,"ToString").runMethod(true,"toLowerCase");
 BA.debugLineNum = 26;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}