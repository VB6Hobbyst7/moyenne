package nl.pdeg.moyenne;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clsfunctions extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new anywheresoftware.b4a.ShellBA(_ba, this, htSubs, "nl.pdeg.moyenne.clsfunctions");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", nl.pdeg.moyenne.clsfunctions.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 
    public void  innerInitializeHelper(anywheresoftware.b4a.BA _ba) throws Exception{
        innerInitialize(_ba);
    }
    public Object callSub(String sub, Object sender, Object[] args) throws Exception {
        return BA.SubDelegator.SubNotFound;
    }
public anywheresoftware.b4a.keywords.Common __c = null;
public String _clvheaderprimarycolor = "";
public String _clvheaderhighlightcolor = "";
public b4a.example.dateutils _dateutils = null;
public nl.pdeg.moyenne.main _main = null;
public nl.pdeg.moyenne.starter _starter = null;
public nl.pdeg.moyenne.discipline _discipline = null;
public String  _initialize(nl.pdeg.moyenne.clsfunctions __ref,anywheresoftware.b4a.BA _ba) throws Exception{
__ref = this;
innerInitialize(_ba);
RDebugUtils.currentModule="clsfunctions";
if (Debug.shouldDelegate(ba, "initialize", false))
	 {return ((String) Debug.delegate(ba, "initialize", new Object[] {_ba}));}
RDebugUtils.currentLine=1966080;
 //BA.debugLineNum = 1966080;BA.debugLine="Public Sub Initialize";
RDebugUtils.currentLine=1966082;
 //BA.debugLineNum = 1966082;BA.debugLine="End Sub";
return "";
}
public int  _colorheader(nl.pdeg.moyenne.clsfunctions __ref,b4a.example3.customlistview _clv,Object _sndr) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsfunctions";
if (Debug.shouldDelegate(ba, "colorheader", false))
	 {return ((Integer) Debug.delegate(ba, "colorheader", new Object[] {_clv,_sndr}));}
int _maxindex = 0;
int _index = 0;
anywheresoftware.b4a.objects.PanelWrapper _pnl = null;
int _i = 0;
anywheresoftware.b4a.objects.ConcreteViewWrapper _v = null;
RDebugUtils.currentLine=2228224;
 //BA.debugLineNum = 2228224;BA.debugLine="Sub colorHeader(clv As CustomListView, sndr As Obj";
RDebugUtils.currentLine=2228226;
 //BA.debugLineNum = 2228226;BA.debugLine="Dim maxIndex As Int = clv.GetSize";
_maxindex = _clv._getsize();
RDebugUtils.currentLine=2228227;
 //BA.debugLineNum = 2228227;BA.debugLine="Dim index As Int = getPanelIndex(clv, sndr)";
_index = __ref._getpanelindex /*int*/ (null,_clv,_sndr);
RDebugUtils.currentLine=2228228;
 //BA.debugLineNum = 2228228;BA.debugLine="Dim pnl As Panel";
_pnl = new anywheresoftware.b4a.objects.PanelWrapper();
RDebugUtils.currentLine=2228230;
 //BA.debugLineNum = 2228230;BA.debugLine="For i = 0 To maxIndex - 1";
{
final int step4 = 1;
final int limit4 = (int) (_maxindex-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
RDebugUtils.currentLine=2228231;
 //BA.debugLineNum = 2228231;BA.debugLine="pnl = clv.GetPanel(i)";
_pnl.setObject((android.view.ViewGroup)(_clv._getpanel(_i).getObject()));
RDebugUtils.currentLine=2228233;
 //BA.debugLineNum = 2228233;BA.debugLine="For Each v As View In pnl.GetAllViewsRecursive";
_v = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
{
final anywheresoftware.b4a.BA.IterableList group6 = _pnl.GetAllViewsRecursive();
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_v.setObject((android.view.View)(group6.Get(index6)));
RDebugUtils.currentLine=2228234;
 //BA.debugLineNum = 2228234;BA.debugLine="If v Is Label Then";
if (_v.getObjectOrNull() instanceof android.widget.TextView) { 
RDebugUtils.currentLine=2228235;
 //BA.debugLineNum = 2228235;BA.debugLine="If v.Tag = \"disci\" Then";
if ((_v.getTag()).equals((Object)("disci"))) { 
RDebugUtils.currentLine=2228236;
 //BA.debugLineNum = 2228236;BA.debugLine="v.Color = clvHeaderPrimaryColor";
_v.setColor((int)(Double.parseDouble(__ref._clvheaderprimarycolor /*String*/ )));
RDebugUtils.currentLine=2228237;
 //BA.debugLineNum = 2228237;BA.debugLine="If i = index Then";
if (_i==_index) { 
RDebugUtils.currentLine=2228238;
 //BA.debugLineNum = 2228238;BA.debugLine="v.Color = clvHeaderHighlightColor";
_v.setColor((int)(Double.parseDouble(__ref._clvheaderhighlightcolor /*String*/ )));
 };
 };
 };
 }
};
 }
};
RDebugUtils.currentLine=2228245;
 //BA.debugLineNum = 2228245;BA.debugLine="Return index";
if (true) return _index;
RDebugUtils.currentLine=2228247;
 //BA.debugLineNum = 2228247;BA.debugLine="End Sub";
return 0;
}
public String  _class_globals(nl.pdeg.moyenne.clsfunctions __ref) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsfunctions";
RDebugUtils.currentLine=1900544;
 //BA.debugLineNum = 1900544;BA.debugLine="Sub Class_Globals";
RDebugUtils.currentLine=1900545;
 //BA.debugLineNum = 1900545;BA.debugLine="Dim clvHeaderPrimaryColor As String =  0xFF05B80A";
_clvheaderprimarycolor = BA.NumberToString(0xff05b80a);
RDebugUtils.currentLine=1900546;
 //BA.debugLineNum = 1900546;BA.debugLine="Dim clvHeaderHighlightColor As String =  0xFF0059";
_clvheaderhighlightcolor = BA.NumberToString(0xff0059ff);
RDebugUtils.currentLine=1900547;
 //BA.debugLineNum = 1900547;BA.debugLine="End Sub";
return "";
}
public int  _getpanelindex(nl.pdeg.moyenne.clsfunctions __ref,b4a.example3.customlistview _clv,Object _sndr) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsfunctions";
if (Debug.shouldDelegate(ba, "getpanelindex", false))
	 {return ((Integer) Debug.delegate(ba, "getpanelindex", new Object[] {_clv,_sndr}));}
RDebugUtils.currentLine=2162688;
 //BA.debugLineNum = 2162688;BA.debugLine="Sub getPanelIndex(clv As CustomListView, sndr As O";
RDebugUtils.currentLine=2162689;
 //BA.debugLineNum = 2162689;BA.debugLine="Return clv.GetItemFromView(sndr)";
if (true) return _clv._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_sndr)));
RDebugUtils.currentLine=2162690;
 //BA.debugLineNum = 2162690;BA.debugLine="End Sub";
return 0;
}
public String  _uuidv4(nl.pdeg.moyenne.clsfunctions __ref) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsfunctions";
if (Debug.shouldDelegate(ba, "uuidv4", false))
	 {return ((String) Debug.delegate(ba, "uuidv4", null));}
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _stp = 0;
int _n = 0;
int _c = 0;
RDebugUtils.currentLine=2031616;
 //BA.debugLineNum = 2031616;BA.debugLine="Sub UUIDv4 As String";
RDebugUtils.currentLine=2031617;
 //BA.debugLineNum = 2031617;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
RDebugUtils.currentLine=2031618;
 //BA.debugLineNum = 2031618;BA.debugLine="sb.Initialize";
_sb.Initialize();
RDebugUtils.currentLine=2031619;
 //BA.debugLineNum = 2031619;BA.debugLine="For Each stp As Int In Array(8, 4, 4, 4, 12)";
{
final Object[] group3 = new Object[]{(Object)(8),(Object)(4),(Object)(4),(Object)(4),(Object)(12)};
final int groupLen3 = group3.length
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_stp = (int)(BA.ObjectToNumber(group3[index3]));
RDebugUtils.currentLine=2031620;
 //BA.debugLineNum = 2031620;BA.debugLine="If sb.Length > 0 Then sb.Append(\"-\")";
if (_sb.getLength()>0) { 
_sb.Append("-");};
RDebugUtils.currentLine=2031621;
 //BA.debugLineNum = 2031621;BA.debugLine="For n = 1 To stp";
{
final int step5 = 1;
final int limit5 = _stp;
_n = (int) (1) ;
for (;_n <= limit5 ;_n = _n + step5 ) {
RDebugUtils.currentLine=2031622;
 //BA.debugLineNum = 2031622;BA.debugLine="Dim c As Int = Rnd(0, 16)";
_c = __c.Rnd((int) (0),(int) (16));
RDebugUtils.currentLine=2031623;
 //BA.debugLineNum = 2031623;BA.debugLine="If c < 10 Then c = c + 48 Else c = c + 55";
if (_c<10) { 
_c = (int) (_c+48);}
else {
_c = (int) (_c+55);};
RDebugUtils.currentLine=2031624;
 //BA.debugLineNum = 2031624;BA.debugLine="If sb.Length = 19 Then c = Asc(\"8\")";
if (_sb.getLength()==19) { 
_c = __c.Asc(BA.ObjectToChar("8"));};
RDebugUtils.currentLine=2031625;
 //BA.debugLineNum = 2031625;BA.debugLine="If sb.Length = 14 Then c = Asc(\"4\")";
if (_sb.getLength()==14) { 
_c = __c.Asc(BA.ObjectToChar("4"));};
RDebugUtils.currentLine=2031626;
 //BA.debugLineNum = 2031626;BA.debugLine="sb.Append(Chr(c))";
_sb.Append(BA.ObjectToString(__c.Chr(_c)));
 }
};
 }
};
RDebugUtils.currentLine=2031629;
 //BA.debugLineNum = 2031629;BA.debugLine="Return sb.ToString.ToLowerCase";
if (true) return _sb.ToString().toLowerCase();
RDebugUtils.currentLine=2031630;
 //BA.debugLineNum = 2031630;BA.debugLine="End Sub";
return "";
}
}