package nl.pdeg.moyenne;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class clsdb extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new anywheresoftware.b4a.ShellBA(_ba, this, htSubs, "nl.pdeg.moyenne.clsdb");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", nl.pdeg.moyenne.clsdb.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 
    public void  innerInitializeHelper(anywheresoftware.b4a.BA _ba) throws Exception{
        innerInitialize(_ba);
    }
    public Object callSub(String sub, Object sender, Object[] args) throws Exception {
        return BA.SubDelegator.SubNotFound;
    }
public anywheresoftware.b4a.keywords.Common __c = null;
public String _db = "";
public anywheresoftware.b4a.sql.SQL _sql = null;
public anywheresoftware.b4a.sql.SQL.CursorWrapper _curs = null;
public String _qry = "";
public b4a.example.dateutils _dateutils = null;
public nl.pdeg.moyenne.main _main = null;
public nl.pdeg.moyenne.starter _starter = null;
public nl.pdeg.moyenne.discipline _discipline = null;
public String  _initialize(nl.pdeg.moyenne.clsdb __ref,anywheresoftware.b4a.BA _ba) throws Exception{
__ref = this;
innerInitialize(_ba);
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "initialize", false))
	 {return ((String) Debug.delegate(ba, "initialize", new Object[] {_ba}));}
RDebugUtils.currentLine=2359296;
 //BA.debugLineNum = 2359296;BA.debugLine="Public Sub Initialize";
RDebugUtils.currentLine=2359297;
 //BA.debugLineNum = 2359297;BA.debugLine="If File.Exists(Starter.share, db) = False Then";
if (__c.File.Exists(_starter._share /*String*/ ,__ref._db /*String*/ )==__c.False) { 
RDebugUtils.currentLine=2359298;
 //BA.debugLineNum = 2359298;BA.debugLine="File.Copy(File.DirAssets, db, Starter.share, db)";
__c.File.Copy(__c.File.getDirAssets(),__ref._db /*String*/ ,_starter._share /*String*/ ,__ref._db /*String*/ );
 };
RDebugUtils.currentLine=2359300;
 //BA.debugLineNum = 2359300;BA.debugLine="End Sub";
return "";
}
public boolean  _disciplineexists(nl.pdeg.moyenne.clsdb __ref,String _disc) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "disciplineexists", false))
	 {return ((Boolean) Debug.delegate(ba, "disciplineexists", new Object[] {_disc}));}
RDebugUtils.currentLine=2621440;
 //BA.debugLineNum = 2621440;BA.debugLine="Sub disciplineExists(disc As String) As Boolean";
RDebugUtils.currentLine=2621441;
 //BA.debugLineNum = 2621441;BA.debugLine="initDb";
__ref._initdb /*String*/ (null);
RDebugUtils.currentLine=2621442;
 //BA.debugLineNum = 2621442;BA.debugLine="qry = \"select count(*) as result from disciplines";
__ref._qry /*String*/  = "select count(*) as result from disciplines where discipline = ?";
RDebugUtils.currentLine=2621443;
 //BA.debugLineNum = 2621443;BA.debugLine="curs = sql.ExecQuery2(qry, Array As String(disc))";
__ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ .setObject((android.database.Cursor)(__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .ExecQuery2(__ref._qry /*String*/ ,new String[]{_disc})));
RDebugUtils.currentLine=2621445;
 //BA.debugLineNum = 2621445;BA.debugLine="curs.Position = 0";
__ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ .setPosition((int) (0));
RDebugUtils.currentLine=2621446;
 //BA.debugLineNum = 2621446;BA.debugLine="If curs.GetInt(\"result\") > 0 Then";
if (__ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ .GetInt("result")>0) { 
RDebugUtils.currentLine=2621447;
 //BA.debugLineNum = 2621447;BA.debugLine="Return True";
if (true) return __c.True;
 };
RDebugUtils.currentLine=2621449;
 //BA.debugLineNum = 2621449;BA.debugLine="Return False";
if (true) return __c.False;
RDebugUtils.currentLine=2621450;
 //BA.debugLineNum = 2621450;BA.debugLine="End Sub";
return false;
}
public String  _adddiscipline(nl.pdeg.moyenne.clsdb __ref,String _disc,String _disciid) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "adddiscipline", false))
	 {return ((String) Debug.delegate(ba, "adddiscipline", new Object[] {_disc,_disciid}));}
RDebugUtils.currentLine=2490368;
 //BA.debugLineNum = 2490368;BA.debugLine="Sub addDiscipline(disc As String, disciId As Strin";
RDebugUtils.currentLine=2490369;
 //BA.debugLineNum = 2490369;BA.debugLine="initDb";
__ref._initdb /*String*/ (null);
RDebugUtils.currentLine=2490370;
 //BA.debugLineNum = 2490370;BA.debugLine="If disciplineExists(disc) = True Then";
if (__ref._disciplineexists /*boolean*/ (null,_disc)==__c.True) { 
RDebugUtils.currentLine=2490371;
 //BA.debugLineNum = 2490371;BA.debugLine="ToastMessageShow($\"${disc} bestaat reeds\"$, True";
__c.ToastMessageShow(BA.ObjectToCharSequence((""+__c.SmartStringFormatter("",(Object)(_disc))+" bestaat reeds")),__c.True);
RDebugUtils.currentLine=2490372;
 //BA.debugLineNum = 2490372;BA.debugLine="Return";
if (true) return "";
 };
RDebugUtils.currentLine=2490374;
 //BA.debugLineNum = 2490374;BA.debugLine="If disciId.Length > 8 Then";
if (_disciid.length()>8) { 
RDebugUtils.currentLine=2490375;
 //BA.debugLineNum = 2490375;BA.debugLine="qry = \"update disciplines set discipline = ? whe";
__ref._qry /*String*/  = "update disciplines set discipline = ? where id = ?";
RDebugUtils.currentLine=2490376;
 //BA.debugLineNum = 2490376;BA.debugLine="sql.ExecNonQuery2(qry, Array As String(disc, dis";
__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .ExecNonQuery2(__ref._qry /*String*/ ,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_disc,_disciid}));
 }else {
RDebugUtils.currentLine=2490378;
 //BA.debugLineNum = 2490378;BA.debugLine="disciId = Starter.clsFunc.UUIDv4";
_disciid = _starter._clsfunc /*nl.pdeg.moyenne.clsfunctions*/ ._uuidv4 /*String*/ (null);
RDebugUtils.currentLine=2490379;
 //BA.debugLineNum = 2490379;BA.debugLine="qry = \"insert into disciplines (id, discipline)";
__ref._qry /*String*/  = "insert into disciplines (id, discipline) values (?,?)";
RDebugUtils.currentLine=2490380;
 //BA.debugLineNum = 2490380;BA.debugLine="sql.ExecNonQuery2(qry, Array As String(disciId,";
__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .ExecNonQuery2(__ref._qry /*String*/ ,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_disciid,_disc}));
 };
RDebugUtils.currentLine=2490384;
 //BA.debugLineNum = 2490384;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.sql.SQL.CursorWrapper  _lstdisciplines(nl.pdeg.moyenne.clsdb __ref) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "lstdisciplines", false))
	 {return ((anywheresoftware.b4a.sql.SQL.CursorWrapper) Debug.delegate(ba, "lstdisciplines", null));}
RDebugUtils.currentLine=2752512;
 //BA.debugLineNum = 2752512;BA.debugLine="Sub lstDisciplines As Cursor";
RDebugUtils.currentLine=2752513;
 //BA.debugLineNum = 2752513;BA.debugLine="initDb";
__ref._initdb /*String*/ (null);
RDebugUtils.currentLine=2752514;
 //BA.debugLineNum = 2752514;BA.debugLine="qry = \"select discipline, id from disciplines ord";
__ref._qry /*String*/  = "select discipline, id from disciplines order by discipline";
RDebugUtils.currentLine=2752515;
 //BA.debugLineNum = 2752515;BA.debugLine="curs = sql.ExecQuery(qry)";
__ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ .setObject((android.database.Cursor)(__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .ExecQuery(__ref._qry /*String*/ )));
RDebugUtils.currentLine=2752516;
 //BA.debugLineNum = 2752516;BA.debugLine="Return curs";
if (true) return __ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ ;
RDebugUtils.currentLine=2752518;
 //BA.debugLineNum = 2752518;BA.debugLine="End Sub";
return null;
}
public String  _closeconnection(nl.pdeg.moyenne.clsdb __ref) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "closeconnection", false))
	 {return ((String) Debug.delegate(ba, "closeconnection", null));}
RDebugUtils.currentLine=2686976;
 //BA.debugLineNum = 2686976;BA.debugLine="Sub closeConnection";
RDebugUtils.currentLine=2686977;
 //BA.debugLineNum = 2686977;BA.debugLine="If sql.IsInitialized Then";
if (__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .IsInitialized()) { 
RDebugUtils.currentLine=2686978;
 //BA.debugLineNum = 2686978;BA.debugLine="sql.Close";
__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .Close();
 };
RDebugUtils.currentLine=2686980;
 //BA.debugLineNum = 2686980;BA.debugLine="If curs.IsInitialized Then";
if (__ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ .IsInitialized()) { 
RDebugUtils.currentLine=2686981;
 //BA.debugLineNum = 2686981;BA.debugLine="curs.Close";
__ref._curs /*anywheresoftware.b4a.sql.SQL.CursorWrapper*/ .Close();
 };
RDebugUtils.currentLine=2686983;
 //BA.debugLineNum = 2686983;BA.debugLine="End Sub";
return "";
}
public String  _deletediscipline(nl.pdeg.moyenne.clsdb __ref,String _id) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "deletediscipline", false))
	 {return ((String) Debug.delegate(ba, "deletediscipline", new Object[] {_id}));}
RDebugUtils.currentLine=2555904;
 //BA.debugLineNum = 2555904;BA.debugLine="Sub deleteDiscipline(id As String)";
RDebugUtils.currentLine=2555905;
 //BA.debugLineNum = 2555905;BA.debugLine="initDb";
__ref._initdb /*String*/ (null);
RDebugUtils.currentLine=2555906;
 //BA.debugLineNum = 2555906;BA.debugLine="qry = \"delete from disciplines where id=?\"";
__ref._qry /*String*/  = "delete from disciplines where id=?";
RDebugUtils.currentLine=2555907;
 //BA.debugLineNum = 2555907;BA.debugLine="sql.ExecNonQuery2(qry, Array As String(id))";
__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .ExecNonQuery2(__ref._qry /*String*/ ,anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_id}));
RDebugUtils.currentLine=2555908;
 //BA.debugLineNum = 2555908;BA.debugLine="End Sub";
return "";
}
public String  _initdb(nl.pdeg.moyenne.clsdb __ref) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
if (Debug.shouldDelegate(ba, "initdb", false))
	 {return ((String) Debug.delegate(ba, "initdb", null));}
RDebugUtils.currentLine=2424832;
 //BA.debugLineNum = 2424832;BA.debugLine="Sub initDb";
RDebugUtils.currentLine=2424833;
 //BA.debugLineNum = 2424833;BA.debugLine="If sql.IsInitialized = False Then";
if (__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .IsInitialized()==__c.False) { 
RDebugUtils.currentLine=2424834;
 //BA.debugLineNum = 2424834;BA.debugLine="sql.Initialize(Starter.share, db, False)";
__ref._sql /*anywheresoftware.b4a.sql.SQL*/ .Initialize(_starter._share /*String*/ ,__ref._db /*String*/ ,__c.False);
 };
RDebugUtils.currentLine=2424836;
 //BA.debugLineNum = 2424836;BA.debugLine="End Sub";
return "";
}
public String  _class_globals(nl.pdeg.moyenne.clsdb __ref) throws Exception{
__ref = this;
RDebugUtils.currentModule="clsdb";
RDebugUtils.currentLine=2293760;
 //BA.debugLineNum = 2293760;BA.debugLine="Sub Class_Globals";
RDebugUtils.currentLine=2293761;
 //BA.debugLineNum = 2293761;BA.debugLine="Private db As String = $\"moyenne.db\"$";
_db = ("moyenne.db");
RDebugUtils.currentLine=2293762;
 //BA.debugLineNum = 2293762;BA.debugLine="Private sql As SQL";
_sql = new anywheresoftware.b4a.sql.SQL();
RDebugUtils.currentLine=2293763;
 //BA.debugLineNum = 2293763;BA.debugLine="Private curs As Cursor";
_curs = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
RDebugUtils.currentLine=2293764;
 //BA.debugLineNum = 2293764;BA.debugLine="Private qry As String";
_qry = "";
RDebugUtils.currentLine=2293765;
 //BA.debugLineNum = 2293765;BA.debugLine="End Sub";
return "";
}
}